import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, ScrollView, Image } from 'react-native';

export default function App() {
  // State to store joke data
  const [joke, setJoke] = useState(null);
  // Loading indicator state
  const [loading, setLoading] = useState(false);
  // Error message state
  const [error, setError] = useState(null);

  // Function to fetch a random joke from API
  const fetchJoke = async () => {
    try {
      setLoading(true);   // Show loading spinner
      setError(null);     // Reset error
      setJoke(null);      // Clear old joke

      const response = await fetch('https://official-joke-api.appspot.com/random_joke');
      if (!response.ok) {
        throw new Error('Failed to fetch joke');
      }

      const data = await response.json();
      setJoke(data);      // Store joke in state
    } catch (err) {
      setError(' Could not load a joke. Try again.');
      console.error(err);
    } finally {
      setLoading(false);  // Hide loading spinner
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      {/* First GIF (Smiling Dog) */}
      <Image
        source={require('./assets/tenor.gif')}
        style={styles.image}
      />

      {/* Second GIF (Funny smile) */}
      <Image
        source={require('./assets/funny.gif')}
        style={styles.image}
      />

      {/* Info text about why jokes matter */}
      <Text style={styles.infoText}>
         Jokes are important because they bring joy, reduce stress, and connect people
        through laughter. A good laugh can brighten your day and make tough times easier.
      </Text>

      {/* App Title */}
      <Text style={styles.title}> :) Random Joke App (: </Text>

      {/* Button to fetch a joke */}
      <TouchableOpacity style={styles.button} onPress={fetchJoke}>
        <Text style={styles.buttonText}> Tell me a joke!</Text>
      </TouchableOpacity>

      {/* Loading Spinner */}
      {loading && <ActivityIndicator size="large" color="#ff6347" style={{ marginTop: 20 }} />}

      {/* Error Message */}
      {error && <Text style={styles.error}>{error}</Text>}

      {/* Joke Box (only shows if joke is fetched) */}
      {joke && !loading && !error && (
        <View style={styles.jokeBox}>
          <Text style={styles.setup}>{joke.setup}</Text>
          <Text style={styles.punchline}>{joke.punchline}</Text>
        </View>
      )}
    </ScrollView>
  );
}

// Styles for the app
const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#ffecd2', // peach background
  },
  image: {
    width: 200,
    height: 200,
    marginBottom: 20,
    borderRadius: 20,
  },
  infoText: {
    fontSize: 16,
    color: '#444',
    textAlign: 'center',
    marginBottom: 20,
    paddingHorizontal: 10,
    fontStyle: 'italic',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#ff4081',
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#6a5acd',
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 30,
    elevation: 5,
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  jokeBox: {
    marginTop: 30,
    padding: 20,
    borderRadius: 15,
    backgroundColor: '#fdfd96',
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 3,
  },
  setup: {
    fontSize: 20,
    fontWeight: '700',
    color: '#333',
    textAlign: 'center',
  },
  punchline: {
    fontSize: 18,
    marginTop: 15,
    fontStyle: 'italic',
    textAlign: 'center',
    color: '#00897b',
  },
  error: {
    marginTop: 20,
    color: '#e91e63',
    fontSize: 16,
    fontWeight: 'bold',
  },
});


